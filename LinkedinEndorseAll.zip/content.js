


function endorseAll() {
  const show = document.querySelector('.pv-skills-section__additional-skills');
  
  if(show!=null){
    var expanded = (show.getAttribute("aria-expanded") === "true");
    if(!expanded){
        show.click();
      }
  }


  let endorse = document.querySelectorAll('.pv-skill-entity__featured-endorse-button-shared');
  endorse.forEach(btn => {
    var pressed = (btn.getAttribute("aria-pressed") === "true");
    if(!pressed){
      btn.click();
    }
  });

}


browser.runtime.onMessage.addListener(endorseAll);
