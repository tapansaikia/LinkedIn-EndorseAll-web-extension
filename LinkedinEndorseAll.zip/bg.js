browser.tabs.onUpdated.addListener(processAction);

function processAction(tabId){
  browser.pageAction.show(tabId)
}

browser.pageAction.onClicked.addListener(sendData)

function sendData(tab){
  browser.tabs.sendMessage(tab.id, {data:'dummyData'})
}
